# Corrida99Reader v4 (OCR)

Versão de leitura visual da tela da 99 Motorista.

- Não rola nem controla a tela.
- Usa AccessibilityService.takeScreenshot (Android 11+) para capturar a tela da 99.
- Usa ML Kit Text Recognition para OCR local no aparelho.
- Acumula os textos enquanto o usuário rola manualmente pelos detalhes da corrida.
- Salva a corrida quando reconhecer: "Você ganhou", duração, distância e data/hora.
- Reconhece também "Preço da corrida" / "Valor pago pela corrida" para calcular a diferença.
- Evita duplicatas pelo identificador derivado de data/hora + duração + distância + ganho.

Pacote da 99 Motorista tratado explicitamente: `com.app99.driver`.

package com.anderson.corrida99reader

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.LinkedHashSet

/**
 * v4: leitura visual por OCR.
 *
 * Não rola, não toca e não controla a interface da 99. Quando a tela da 99 muda
 * (inclusive quando o usuário rola manualmente), tira uma captura da tela e passa
 * a imagem pelo ML Kit OCR. Os textos de várias posições da mesma corrida são
 * acumulados até haver dados suficientes para salvar.
 */
class RideAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val captured = LinkedHashSet<String>()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var lastScreenshotAt = 0L
    private var last99EventAt = 0L
    private var lastSaveAt = 0L
    private var screenshotBusy = false
    private var saving = false
    private var rideScreenSeen = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!is99Package(pkg)) return

        last99EventAt = System.currentTimeMillis()
        requestOcrScreenshot(pkg)
    }

    private fun requestOcrScreenshot(sourcePackage: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            debug("OCR indisponível: o Android precisa ser 11 ou superior.")
            return
        }

        val now = System.currentTimeMillis()
        if (screenshotBusy || now - lastScreenshotAt < 650L) return
        lastScreenshotAt = now
        screenshotBusy = true

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            ContextCompat.getMainExecutor(this),
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val buffer = screenshot.hardwareBuffer
                    val hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    val bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()

                    if (bitmap == null) {
                        screenshotBusy = false
                        debug("A captura da tela foi recebida, mas não pôde ser convertida em imagem.")
                        return
                    }

                    recognizer.process(InputImage.fromBitmap(bitmap, 0))
                        .addOnSuccessListener { result ->
                            bitmap.recycle()
                            handleOcr(result, sourcePackage)
                        }
                        .addOnFailureListener { error ->
                            bitmap.recycle()
                            debug("Erro no OCR: ${error.message ?: error.javaClass.simpleName}")
                        }
                        .addOnCompleteListener { screenshotBusy = false }
                }

                override fun onFailure(errorCode: Int) {
                    screenshotBusy = false
                    debug("Falha ao capturar a tela para OCR. Código: $errorCode")
                }
            }
        )
    }

    private fun handleOcr(result: Text, sourcePackage: String) {
        // O ML Kit devolve também a posição de cada linha. A 99 usa muito layout em
        // duas colunas (rótulo à esquerda, valor à direita); por isso NÃO podemos
        // confiar apenas na ordem de result.text. Criamos pares espaciais sintéticos,
        // por exemplo: "Você ganhou: R$ 7,20".
        val visibleLines = result.textBlocks.flatMap { it.lines }
        val rawLines = visibleLines.map { it.text.trim() }.filter { it.isNotBlank() }
        if (rawLines.isEmpty()) {
            debug("OCR executou, mas não encontrou texto visível na tela da 99.")
            return
        }

        val pairedLines = buildSpatialPairs(visibleLines)
        val lines = (rawLines + pairedLines).distinct()

        val hasDetails = lines.any {
            it.contains("Detalhes da corrida", true) || it.contains("Detalhes corrida", true)
        }
        val hasEarned = lines.any {
            it.contains("Você ganhou", true) || it.contains("Voce ganhou", true)
        }

        if (!rideScreenSeen && !hasDetails && !hasEarned) {
            debug("OCR funcionando. Tela da 99 lida, mas ainda não é uma tela de detalhes.\n" + lines.take(25).joinToString(" | "))
            return
        }

        if ((hasDetails || hasEarned) && !rideScreenSeen && System.currentTimeMillis() - lastSaveAt > 1_200L) {
            captured.clear()
        }
        rideScreenSeen = true
        captured.addAll(lines)

        val snapshot = captured.toList()
        val parsed = RideParser.parse(snapshot)
        val status = if (parsed == null) "aguardando campos" else if (parsed.paidForRide == null) "aguardando Pago por esta corrida" else "dados completos"
        debug(
            "OCR ATIVO ✓ • ${captured.size} textos acumulados • $status\n" +
                captured.take(90).joinToString(" | ")
        )

        if (saving || parsed == null) return
        // O cálculo pedido depende desse campo. Não salvamos cedo demais antes de o
        // usuário rolar até a seção 'Pago pelo passageiro'.
        if (parsed.paidForRide == null) return

        saving = true
        scope.launch {
            try {
                save(parsed, snapshot, sourcePackage)
                lastSaveAt = System.currentTimeMillis()
                captured.clear()
                rideScreenSeen = false
            } finally {
                saving = false
            }
        }
    }

    private fun buildSpatialPairs(lines: List<Text.Line>): List<String> {
        val specs = listOf(
            PairSpec(listOf("Você ganhou", "Voce ganhou"), ValueKind.MONEY),
            PairSpec(listOf("Pago por esta corrida", "Valor pago pela corrida"), ValueKind.MONEY),
            PairSpec(listOf("Dinheiro recebido"), ValueKind.MONEY),
            PairSpec(listOf("Valor a receber da 99"), ValueKind.MONEY),
            PairSpec(listOf("99 completou", "A 99 completou", "Completado pela 99"), ValueKind.MONEY),
            PairSpec(listOf("Outras cobranças", "Outras cobrancas"), ValueKind.MONEY),
            PairSpec(listOf("Duração", "Duracao"), ValueKind.DURATION),
            PairSpec(listOf("Distância", "Distancia"), ValueKind.DISTANCE)
        )

        val out = mutableListOf<String>()
        for (spec in specs) {
            for (anchor in lines) {
                val label = spec.labels.firstOrNull { anchor.text.contains(it, ignoreCase = true) } ?: continue

                // Se o valor já veio na mesma linha, preservamos a própria linha.
                if (matchesKind(anchor.text, spec.kind)) {
                    out += anchor.text.trim()
                    continue
                }

                val a = anchor.boundingBox ?: continue
                val acx = (a.left + a.right) / 2.0
                val acy = (a.top + a.bottom) / 2.0

                val best = lines.asSequence()
                    .filter { it !== anchor && matchesKind(it.text, spec.kind) }
                    .mapNotNull { candidate ->
                        val b = candidate.boundingBox ?: return@mapNotNull null
                        val bcx = (b.left + b.right) / 2.0
                        val bcy = (b.top + b.bottom) / 2.0
                        val dy = bcy - acy
                        val dx = bcx - acx
                        val sameRow = kotlin.math.abs(dy) <= maxOf(a.height(), b.height()) * 1.4
                        val below = dy > 0 && dy <= maxOf(260.0, a.height() * 5.0)
                        if (!sameRow && !below) return@mapNotNull null

                        // Favorece valor à direita na mesma linha; para cabeçalhos como
                        // 'Você ganhou', favorece o valor logo abaixo.
                        val score = if (sameRow) {
                            kotlin.math.abs(dy) * 4.0 + kotlin.math.abs(dx) + if (dx < -40) 700.0 else 0.0
                        } else {
                            dy * 2.0 + kotlin.math.abs(dx) * 0.65
                        }
                        candidate to score
                    }
                    .minByOrNull { it.second }
                    ?.first

                if (best != null) out += "$label: ${best.text.trim()}"
            }
        }
        return out.distinct()
    }

    private fun matchesKind(text: String, kind: ValueKind): Boolean = when (kind) {
        ValueKind.MONEY -> RideParser.parseMoney(text) != null
        ValueKind.DISTANCE -> Regex("[0-9]+(?:[.,][0-9]+)?\\s*km", RegexOption.IGNORE_CASE).containsMatchIn(text)
        ValueKind.DURATION -> Regex("(?:\\d+\\s*h)?\\s*(?:\\d+\\s*(?:min|m))?\\s*(?:\\d+\\s*s)?", RegexOption.IGNORE_CASE)
            .findAll(text).any { m -> m.value.any(Char::isDigit) && Regex("h|min|m|s", RegexOption.IGNORE_CASE).containsMatchIn(m.value) }
    }

    private data class PairSpec(val labels: List<String>, val kind: ValueKind)
    private enum class ValueKind { MONEY, DISTANCE, DURATION }

    private suspend fun save(parsed: RideParser.ParsedRide, raw: List<String>, packageName: String?) {
        val entity = RideParser.toEntity(parsed, packageName, raw)
        val db = AppDatabase.get(this)
        val result = withContext(Dispatchers.IO) { db.rideDao().insert(entity) }

        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_99_package", packageName)
            .putString("last_ride", "${entity.dateTime} • ${entity.distanceKm} km • ${entity.duration} • R$ ${"%.2f".format(entity.earned)}")
            .apply()

        if (result == -1L) {
            Toast.makeText(this, "Corrida já registrada — ignorada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Corrida salva: R$ ${"%.2f".format(entity.earned)}", Toast.LENGTH_SHORT).show()
            val rides = withContext(Dispatchers.IO) { db.rideDao().ridesForDate(entity.date) }
            withContext(Dispatchers.IO) {
                runCatching { HistoryExporter.exportDay(this@RideAccessibilityService, entity.date, rides) }
            }
        }
    }

    private fun debug(message: String) {
        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_capture_debug", message)
            .apply()
    }

    private fun is99Package(pkg: String): Boolean {
        return pkg == "com.app99.driver" ||
            pkg == "com.taxis99" ||
            pkg == "com.didiglobal.driver" ||
            pkg == "com.driver99" ||
            pkg.contains("app99", true)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        recognizer.close()
        super.onDestroy()
    }
}

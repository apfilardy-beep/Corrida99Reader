package com.anderson.corrida99reader

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.LinkedHashSet

/**
 * v4: leitura visual por OCR.
 *
 * Não rola, não toca e não controla a interface da 99. Quando a tela da 99 muda
 * (inclusive quando o usuário rola manualmente), tira uma captura da tela e passa
 * a imagem pelo ML Kit OCR. Os textos de várias posições da mesma corrida são
 * acumulados até haver dados suficientes para salvar.
 */
class RideAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val captured = LinkedHashSet<String>()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var lastScreenshotAt = 0L
    private var last99EventAt = 0L
    private var lastSaveAt = 0L
    private var screenshotBusy = false
    private var saving = false
    private var rideScreenSeen = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (!is99Package(pkg)) return

        last99EventAt = System.currentTimeMillis()
        requestOcrScreenshot(pkg)
    }

    private fun requestOcrScreenshot(sourcePackage: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            debug("OCR indisponível: o Android precisa ser 11 ou superior.")
            return
        }

        val now = System.currentTimeMillis()
        if (screenshotBusy || now - lastScreenshotAt < 650L) return
        lastScreenshotAt = now
        screenshotBusy = true

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            ContextCompat.getMainExecutor(this),
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val buffer = screenshot.hardwareBuffer
                    val hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    val bitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()

                    if (bitmap == null) {
                        screenshotBusy = false
                        debug("A captura da tela foi recebida, mas não pôde ser convertida em imagem.")
                        return
                    }

                    recognizer.process(InputImage.fromBitmap(bitmap, 0))
                        .addOnSuccessListener { result ->
                            bitmap.recycle()
                            handleOcr(result.text, sourcePackage)
                        }
                        .addOnFailureListener { error ->
                            bitmap.recycle()
                            debug("Erro no OCR: ${error.message ?: error.javaClass.simpleName}")
                        }
                        .addOnCompleteListener { screenshotBusy = false }
                }

                override fun onFailure(errorCode: Int) {
                    screenshotBusy = false
                    debug("Falha ao capturar a tela para OCR. Código: $errorCode")
                }
            }
        )
    }

    private fun handleOcr(fullText: String, sourcePackage: String) {
        val lines = fullText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toList()

        if (lines.isEmpty()) {
            debug("OCR executou, mas não encontrou texto visível na tela da 99.")
            return
        }

        val hasDetails = lines.any {
            it.contains("Detalhes da corrida", true) ||
                it.contains("Detalhes corrida", true)
        }
        val hasEarned = lines.any {
            it.contains("Você ganhou", true) || it.contains("Voce ganhou", true)
        }

        // Só começamos a acumular uma corrida depois de reconhecer a tela de detalhes.
        if (!rideScreenSeen && !hasDetails && !hasEarned) {
            debug("OCR funcionando. Tela da 99 lida, mas ainda não é uma tela de detalhes.\n" + lines.take(25).joinToString(" | "))
            return
        }

        // Uma tela de detalhes reaparecendo depois de uma corrida salva inicia nova coleta.
        if ((hasDetails || hasEarned) && !rideScreenSeen && System.currentTimeMillis() - lastSaveAt > 1_200L) {
            captured.clear()
        }
        rideScreenSeen = true
        captured.addAll(lines)

        debug(
            "OCR ATIVO ✓ • ${captured.size} textos acumulados\n" +
                captured.take(80).joinToString(" | ")
        )

        if (saving) return
        val parsed = RideParser.parse(captured.toList()) ?: return
        saving = true
        val snapshot = captured.toList()

        scope.launch {
            try {
                save(parsed, snapshot, sourcePackage)
                lastSaveAt = System.currentTimeMillis()
                captured.clear()
                rideScreenSeen = false
            } finally {
                saving = false
            }
        }
    }

    private suspend fun save(parsed: RideParser.ParsedRide, raw: List<String>, packageName: String?) {
        val entity = RideParser.toEntity(parsed, packageName, raw)
        val db = AppDatabase.get(this)
        val result = withContext(Dispatchers.IO) { db.rideDao().insert(entity) }

        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_99_package", packageName)
            .putString("last_ride", "${entity.dateTime} • ${entity.distanceKm} km • ${entity.duration} • R$ ${"%.2f".format(entity.earned)}")
            .apply()

        if (result == -1L) {
            Toast.makeText(this, "Corrida já registrada — ignorada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Corrida salva: R$ ${"%.2f".format(entity.earned)}", Toast.LENGTH_SHORT).show()
            val rides = withContext(Dispatchers.IO) { db.rideDao().ridesForDate(entity.date) }
            withContext(Dispatchers.IO) {
                runCatching { HistoryExporter.exportDay(this@RideAccessibilityService, entity.date, rides) }
            }
        }
    }

    private fun debug(message: String) {
        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_capture_debug", message)
            .apply()
    }

    private fun is99Package(pkg: String): Boolean {
        return pkg == "com.app99.driver" ||
            pkg == "com.taxis99" ||
            pkg == "com.didiglobal.driver" ||
            pkg == "com.driver99" ||
            pkg.contains("app99", true)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        recognizer.close()
        super.onDestroy()
    }
}

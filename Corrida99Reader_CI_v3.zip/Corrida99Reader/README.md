# Leitor 99 Corridas

Aplicativo Android em Kotlin que usa `AccessibilityService` para ler a tela **Detalhes da corrida** da 99, ler passivamente os textos exibidos, extrair os valores e guardar o histórico. O app não controla nem rola a tela automaticamente.

## O que já está implementado

- Leitura dos textos da tela via Acessibilidade (sem OCR quando a 99 expõe o texto ao Android).
- Leitura passiva: não rola nem controla a tela da 99; acumula os textos conforme o usuário navega/rola manualmente.
- Campos principais:
  - Você ganhou
  - Duração
  - Distância
  - Pago por esta corrida
  - Dinheiro recebido
  - Valor a receber da 99
  - 99 completou / complemento da 99
  - Outras cobranças
  - Método de pagamento
  - Tipo de corrida
  - Data e hora
  - Origem e destino (quando aparecem como texto acessível)
- Cálculo `Você ganhou - Pago por esta corrida`.
- Antiduplicação por SHA-256 de `data/hora + duração + distância + valor ganho`.
- Banco local Room.
- Histórico dentro do app.
- Exportação automática e no botão **Finalizar leitura do dia** para:
  - `Documentos/Corrida99/DD-MM-AAAA/corridas.json`
  - `Documentos/Corrida99/DD-MM-AAAA/corridas.csv`
  - `Documentos/Corrida99/DD-MM-AAAA/resumo.txt`

## Como abrir e gerar o APK

1. Instale Android Studio.
2. Abra a pasta `Corrida99Reader` como projeto.
3. Aguarde o Gradle sincronizar e baixar as dependências.
4. Conecte o celular com Depuração USB ou gere o APK em **Build > Build APK(s)**.
5. Instale o APK.
6. Abra o app e toque em **Ativar serviço de acessibilidade**.
7. Ative **Leitor de corridas 99**.
8. Abra a 99 e entre nos detalhes de uma corrida.

## Importante para Xiaomi / POCO / HyperOS

Para o serviço não ser encerrado:
- Bateria do app: **Sem restrições**.
- Permitir inicialização automática, se essa opção existir.
- Manter o app bloqueado nos recentes pode ajudar em versões agressivas do HyperOS.

## Limitação conhecida

Se alguma versão da 99 desenhar um campo como imagem/canvas e não o expuser à árvore de acessibilidade, esse campo não será lido. Nesse caso o próximo passo é adicionar captura de tela + OCR somente como fallback.

## Privacidade

Os dados ficam no aparelho. O projeto não possui servidor, login nem envio de corridas para terceiros.

package com.anderson.corrida99reader

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.LinkedHashSet

/**
 * Leitor passivo: nunca executa ações na interface da 99.
 * Ele apenas observa os textos expostos pela Acessibilidade.
 * Se o usuário rolar a tela manualmente, os textos das várias partes são acumulados
 * até haver dados suficientes para salvar a corrida.
 */
class RideAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private val captured = LinkedHashSet<String>()
    private var lastEventAt = 0L
    private var lastSaveAt = 0L
    private var saving = false
    private var rideScreenActive = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        val root = rootInActiveWindow ?: return
        val visible = collectTexts(root).toMutableList()

        // Alguns apps expõem texto no próprio evento mesmo quando ele não aparece
        // como um nó normal da árvore de acessibilidade.
        event?.text?.mapNotNull { it?.toString()?.trim() }
            ?.filter { it.isNotBlank() }
            ?.forEach { if (it !in visible) visible.add(it) }
        event?.contentDescription?.toString()?.trim()
            ?.takeIf { it.isNotBlank() && it !in visible }
            ?.let(visible::add)

        val isRideScreen = containsRideDetails(visible) ||
            visible.any { it.contains("Você ganhou", true) || it.contains("Voce ganhou", true) }

        // Se ficamos muito tempo fora de uma corrida, descartamos a captura parcial anterior.
        if (!isRideScreen && rideScreenActive && now - lastEventAt > 15_000) {
            captured.clear()
            rideScreenActive = false
        }

        if (!isRideScreen && !rideScreenActive) return

        // Ao abrir uma nova tela de detalhes depois de uma corrida salva, inicia nova captura.
        if (isRideScreen && now - lastSaveAt > 1_500 && !rideScreenActive) {
            captured.clear()
        }

        rideScreenActive = true
        lastEventAt = now
        captured.addAll(visible)

        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString(
                "last_capture_debug",
                "Leitura passiva ativa. Textos capturados: ${captured.size}\n" +
                    captured.take(60).joinToString(" | ")
            )
            .apply()

        if (saving) return
        val parsed = RideParser.parse(captured.toList()) ?: return

        saving = true
        val snapshot = captured.toList()
        val packageName = event?.packageName?.toString()
        scope.launch {
            try {
                save(parsed, snapshot, packageName)
                lastSaveAt = System.currentTimeMillis()
                captured.clear()
                rideScreenActive = false
            } finally {
                saving = false
            }
        }
    }

    private suspend fun save(parsed: RideParser.ParsedRide, raw: List<String>, packageName: String?) {
        val entity = RideParser.toEntity(parsed, packageName, raw)
        val db = AppDatabase.get(this)
        val result = withContext(Dispatchers.IO) { db.rideDao().insert(entity) }

        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_99_package", packageName)
            .putString("last_ride", "${entity.dateTime} • ${entity.distanceKm} km • ${entity.duration} • R$ ${"%.2f".format(entity.earned)}")
            .apply()

        if (result == -1L) {
            Toast.makeText(this, "Corrida já registrada — ignorada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Corrida salva: R$ ${"%.2f".format(entity.earned)}", Toast.LENGTH_SHORT).show()
            val rides = withContext(Dispatchers.IO) { db.rideDao().ridesForDate(entity.date) }
            withContext(Dispatchers.IO) {
                runCatching { HistoryExporter.exportDay(this@RideAccessibilityService, entity.date, rides) }
            }
        }
    }

    private fun collectTexts(root: AccessibilityNodeInfo): List<String> {
        val result = mutableListOf<String>()
        fun add(value: CharSequence?) {
            value?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
        }
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            add(node.text)
            add(node.contentDescription)
            if (android.os.Build.VERSION.SDK_INT >= 26) add(node.hintText)
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                add(node.paneTitle)
                add(node.tooltipText)
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) add(node.stateDescription)
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return result
    }

    private fun containsRideDetails(items: Collection<String>): Boolean =
        items.any { it.contains("Detalhes da corrida", ignoreCase = true) }

    override fun onInterrupt() = Unit
}

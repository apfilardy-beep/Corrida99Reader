package com.anderson.corrida99reader

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.LinkedHashSet

class RideAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var collecting = false
    private var lastTriggerAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        if (collecting || now - lastTriggerAt < 900) return
        val root = rootInActiveWindow ?: return
        val initial = collectTexts(root)
        if (!containsRideDetails(initial)) return

        lastTriggerAt = now
        collecting = true
        scope.launch {
            try {
                captureRide(event?.packageName?.toString())
            } finally {
                collecting = false
            }
        }
    }

    private suspend fun captureRide(packageName: String?) {
        val all = LinkedHashSet<String>()
        var stagnant = 0
        var lastSize = 0

        repeat(10) {
            val root = rootInActiveWindow ?: return@repeat
            all.addAll(collectTexts(root))

            if (all.size == lastSize) stagnant++ else stagnant = 0
            lastSize = all.size

            val parsed = RideParser.parse(all.toList())
            val hasBottom = hasDateTime(all) && containsRideDetails(all)
            if (parsed != null && hasBottom && stagnant >= 1) {
                save(parsed, all.toList(), packageName)
                return
            }

            val scrolled = scrollForward(root)
            if (!scrolled || stagnant >= 2) {
                val snapshot = all.toList()
                val partial = RideParser.parse(snapshot)
                if (partial != null) save(partial, snapshot, packageName)
                else reportReadFailure(snapshot)
                return
            }
            delay(650)
        }

        val finalItems = all.toList()
        val finalParsed = RideParser.parse(finalItems)
        if (finalParsed != null) {
            save(finalParsed, finalItems, packageName)
        } else {
            reportReadFailure(finalItems)
        }
    }

    private fun reportReadFailure(items: List<String>) {
        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_capture_debug", "Tela detectada, mas faltaram dados. Textos capturados: ${items.size}\n" + items.take(40).joinToString(" | "))
            .apply()
        Toast.makeText(this, "Tela lida, mas não consegui identificar todos os dados", Toast.LENGTH_LONG).show()
    }

    private suspend fun save(parsed: RideParser.ParsedRide, raw: List<String>, packageName: String?) {
        val entity = RideParser.toEntity(parsed, packageName, raw)
        val db = AppDatabase.get(this)
        val result = withContext(Dispatchers.IO) { db.rideDao().insert(entity) }

        getSharedPreferences("prefs", MODE_PRIVATE).edit()
            .putString("last_99_package", packageName)
            .putString("last_ride", "${entity.dateTime} • ${entity.distanceKm} km • ${entity.duration} • R$ ${"%.2f".format(entity.earned)}")
            .apply()

        if (result == -1L) {
            Toast.makeText(this, "Corrida já registrada — ignorada", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Corrida salva: R$ ${"%.2f".format(entity.earned)}", Toast.LENGTH_SHORT).show()
            val rides = withContext(Dispatchers.IO) { db.rideDao().ridesForDate(entity.date) }
            withContext(Dispatchers.IO) {
                runCatching { HistoryExporter.exportDay(this@RideAccessibilityService, entity.date, rides) }
            }
        }
    }

    private fun collectTexts(root: AccessibilityNodeInfo): List<String> {
        val result = mutableListOf<String>()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(result::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                node.hintText?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
            }
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                node.paneTitle?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
                node.tooltipText?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
            }
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                node.stateDescription?.toString()?.trim()?.takeIf { it.isNotBlank() && it !in result }?.let(result::add)
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return result
    }

    private fun scrollForward(root: AccessibilityNodeInfo): Boolean {
        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isScrollable) return node
            for (i in 0 until node.childCount) findScrollable(node.getChild(i))?.let { return it }
            return null
        }
        val scrollable = findScrollable(root) ?: return false
        return scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    private fun containsRideDetails(items: Collection<String>): Boolean =
        items.any { it.contains("Detalhes da corrida", ignoreCase = true) } &&
        items.any { it.contains("Você ganhou", ignoreCase = true) || it.contains("Voce ganhou", ignoreCase = true) }

    private fun hasDateTime(items: Collection<String>): Boolean =
        items.any { Regex("\\d{2}/\\d{2}/\\d{4}\\s+\\d{2}:\\d{2}:\\d{2}").containsMatchIn(it) }

    override fun onInterrupt() = Unit
}

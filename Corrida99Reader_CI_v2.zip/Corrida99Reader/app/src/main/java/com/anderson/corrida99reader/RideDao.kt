package com.anderson.corrida99reader

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RideDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(ride: RideEntity): Long

    @Query("SELECT * FROM rides WHERE date = :date ORDER BY dateTime ASC")
    suspend fun ridesForDate(date: String): List<RideEntity>

    @Query("SELECT * FROM rides ORDER BY dateTime DESC LIMIT 200")
    fun recentRides(): Flow<List<RideEntity>>

    @Query("SELECT * FROM rides WHERE date = :date ORDER BY dateTime DESC")
    fun ridesForDateFlow(date: String): Flow<List<RideEntity>>
}

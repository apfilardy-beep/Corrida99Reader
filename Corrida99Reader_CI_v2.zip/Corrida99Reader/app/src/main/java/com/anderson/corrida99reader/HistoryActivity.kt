package com.anderson.corrida99reader

import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.anderson.corrida99reader.databinding.ActivityHistoryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)

        lifecycleScope.launch {
            AppDatabase.get(this@HistoryActivity).rideDao().recentRides().collectLatest { rides ->
                val rows = rides.map { r ->
                    buildString {
                        append("${r.dateTime}  •  ${r.distanceKm} km  •  ${r.duration}\n")
                        append("Você ganhou: R$ ${"%.2f".format(r.earned)}")
                        r.paidForRide?.let { append("  |  Pago: R$ ${"%.2f".format(it)}") }
                        r.difference?.let { append("  |  Dif.: R$ ${"%.2f".format(it)}") }
                    }
                }
                b.listHistory.adapter = ArrayAdapter(this@HistoryActivity, android.R.layout.simple_list_item_1, rows)
            }
        }
    }
}

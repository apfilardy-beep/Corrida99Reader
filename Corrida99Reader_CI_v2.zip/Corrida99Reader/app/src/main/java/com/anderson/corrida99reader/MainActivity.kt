package com.anderson.corrida99reader

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.anderson.corrida99reader.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val db by lazy { AppDatabase.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        b.btnOpen99.setOnClickListener { open99() }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnFinalize.setOnClickListener { finalizeToday() }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        observeToday()
    }

    private fun observeToday() {
        val today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        lifecycleScope.launch {
            db.rideDao().ridesForDateFlow(today).collectLatest { rides ->
                val total = rides.sumOf { it.earned }
                b.tvToday.text = "Hoje: ${rides.size} corridas • Você ganhou R$ ${"%.2f".format(total)}"
                b.tvLastRide.text = rides.firstOrNull()?.let {
                    "Última: ${it.dateTime}\n${it.duration} • ${it.distanceKm} km • R$ ${"%.2f".format(it.earned)}"
                } ?: getSharedPreferences("prefs", MODE_PRIVATE).let { prefs ->
                    prefs.getString("last_capture_debug", null)
                        ?: prefs.getString("last_ride", "Nenhuma corrida lida ainda.")
                }
            }
        }
    }

    private fun refreshStatus() {
        val cn = ComponentName(this, RideAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(':')?.any { it.equals(cn, ignoreCase = true) } == true
        b.tvServiceStatus.text = if (enabled) "Serviço: ATIVO ✓" else "Serviço: DESATIVADO"
    }

    private fun open99() {
        val prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        val detected = prefs.getString("last_99_package", null)
        val candidates = listOfNotNull(detected, "com.taxis99", "com.didiglobal.driver", "com.driver99")
        val intent = candidates.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Abra o app da 99 manualmente uma vez. Depois o leitor memoriza o pacote correto.", Toast.LENGTH_LONG).show()
    }

    private fun finalizeToday() {
        val today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        lifecycleScope.launch {
            val rides = withContext(Dispatchers.IO) { db.rideDao().ridesForDate(today) }
            if (rides.isEmpty()) {
                Toast.makeText(this@MainActivity, "Nenhuma corrida salva hoje.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val files = withContext(Dispatchers.IO) { HistoryExporter.exportDay(this@MainActivity, today, rides) }
            Toast.makeText(this@MainActivity, "Dia finalizado. Arquivos salvos em Documentos/Corrida99/${today.replace('/', '-')}", Toast.LENGTH_LONG).show()
        }
    }
}

package com.anderson.corrida99reader

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object HistoryExporter {
    suspend fun exportDay(context: Context, date: String, rides: List<RideEntity>): List<String> {
        if (rides.isEmpty()) return emptyList()
        val safeDate = date.replace('/', '-')
        val path = "${Environment.DIRECTORY_DOCUMENTS}/Corrida99/$safeDate"

        val totalEarned = rides.sumOf { it.earned }
        val totalPaid = rides.sumOf { it.paidForRide ?: 0.0 }
        val totalDiff = rides.sumOf { it.difference ?: 0.0 }
        val totalFrom99 = rides.sumOf { it.amountFrom99 ?: 0.0 }
        val totalCompleted99 = rides.sumOf { it.completedBy99 ?: 0.0 }
        val totalCharges = rides.sumOf { it.otherCharges ?: 0.0 }
        val totalCash = rides.sumOf { it.cashReceived ?: 0.0 }
        val totalKm = rides.sumOf { it.distanceKm }

        val json = JSONObject().apply {
            put("data", date)
            put("quantidade_corridas", rides.size)
            put("distancia_total_km", totalKm)
            put("voce_ganhou_total", totalEarned)
            put("pago_por_esta_corrida_total", totalPaid)
            put("diferenca_total", totalDiff)
            put("valor_a_receber_da_99_total", totalFrom99)
            put("99_completou_total", totalCompleted99)
            put("outras_cobrancas_total", totalCharges)
            put("dinheiro_recebido_total", totalCash)
            put("corridas", JSONArray().apply {
                rides.forEach { r ->
                    put(JSONObject().apply {
                        put("id", r.id)
                        put("data_hora", r.dateTime)
                        put("duracao", r.duration)
                        put("distancia_km", r.distanceKm)
                        put("voce_ganhou", r.earned)
                        put("pago_por_esta_corrida", r.paidForRide)
                        put("diferenca", r.difference)
                        put("dinheiro_recebido", r.cashReceived)
                        put("valor_a_receber_da_99", r.amountFrom99)
                        put("99_completou", r.completedBy99)
                        put("outras_cobrancas", r.otherCharges)
                        put("metodo_pagamento", r.paymentMethod)
                        put("tipo_corrida", r.rideType)
                        put("origem", r.pickup)
                        put("destino", r.dropoff)
                    })
                }
            })
        }.toString(2)

        val csv = buildString {
            appendLine("data_hora;duracao;distancia_km;voce_ganhou;pago_por_esta_corrida;diferenca;dinheiro_recebido;valor_a_receber_da_99;99_completou;outras_cobrancas;metodo_pagamento;origem;destino")
            rides.forEach { r ->
                appendLine(listOf(
                    r.dateTime, r.duration, fmt(r.distanceKm), fmt(r.earned), fmt(r.paidForRide),
                    fmt(r.difference), fmt(r.cashReceived), fmt(r.amountFrom99), fmt(r.completedBy99),
                    fmt(r.otherCharges), csvEscape(r.paymentMethod), csvEscape(r.pickup), csvEscape(r.dropoff)
                ).joinToString(";"))
            }
        }

        val summary = """
            RESUMO — $date

            Corridas: ${rides.size}
            Distância total: ${"%.2f".format(Locale.US, totalKm)} km

            Você ganhou: R$ ${br(totalEarned)}
            Pago por esta corrida: R$ ${br(totalPaid)}
            Diferença: R$ ${br(totalDiff)}
            Valor a receber da 99: R$ ${br(totalFrom99)}
            99 completou: R$ ${br(totalCompleted99)}
            Outras cobranças: R$ ${br(totalCharges)}
            Dinheiro recebido: R$ ${br(totalCash)}
        """.trimIndent()

        val outputs = mutableListOf<String>()
        outputs += writeText(context, path, "corridas.json", "application/json", json)
        outputs += writeText(context, path, "corridas.csv", "text/csv", csv)
        outputs += writeText(context, path, "resumo.txt", "text/plain", summary)
        return outputs
    }

    private fun writeText(context: Context, relativePath: String, name: String, mime: String, content: String): String {
        val resolver = context.contentResolver
        val existing = resolver.query(
            MediaStore.Files.getContentUri("external"),
            arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(name, "$relativePath/"), null
        )
        existing?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getLong(0)
                resolver.delete(MediaStore.Files.getContentUri("external", id), null, null)
            }
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
        }
        val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
            ?: error("Não foi possível criar $name")
        resolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
            ?: error("Não foi possível gravar $name")
        return "$relativePath/$name"
    }

    private fun fmt(v: Double?): String = v?.let { "%.2f".format(Locale.US, it) } ?: ""
    private fun csvEscape(v: String?): String = v?.replace(";", ",") ?: ""
    private fun br(v: Double): String = "%.2f".format(Locale("pt", "BR"), v)
}

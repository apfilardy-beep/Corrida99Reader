package com.anderson.corrida99reader

import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale

object RideParser {
    data class ParsedRide(
        val dateTime: String,
        val date: String,
        val duration: String,
        val distanceKm: Double,
        val earned: Double,
        val paidForRide: Double?,
        val cashReceived: Double?,
        val amountFrom99: Double?,
        val completedBy99: Double?,
        val otherCharges: Double?,
        val paymentMethod: String?,
        val rideType: String?,
        val pickup: String?,
        val dropoff: String?,
        val passenger: String?
    )

    fun parse(items: List<String>): ParsedRide? {
        val clean = items.map { it.trim() }.filter { it.isNotBlank() }
        val joined = clean.joinToString("\n")
        if (!normalize(joined).contains("detalhes da corrida")) return null

        // A 99 pode expor rótulo e valor no mesmo nó de acessibilidade ou em nós separados.
        // Estas buscas aceitam os dois formatos.
        val earned = moneyNear(clean, listOf("Você ganhou", "Voce ganhou")) ?: return null
        val duration = durationNear(clean, listOf("Duração", "Duracao")) ?: return null
        val distance = distanceNear(clean, listOf("Distância", "Distancia")) ?: return null
        val dateTime = findDateTime(joined) ?: return null
        val date = dateTime.substring(0, 10)

        val paid = moneyNear(clean, listOf("Pago por esta corrida"))
        val cash = moneyNear(clean, listOf("Dinheiro recebido"))
        val from99 = moneyNear(clean, listOf("Valor a receber da 99", "Recebido pela 99"))
        val completed99 = moneyNear(clean, listOf("99 completou", "Completado pela 99", "Complemento da 99"))
        val otherCharges = moneyNear(clean, listOf("Outras cobranças", "Outras cobrancas"))
        val paymentMethod = textNear(clean, listOf("Método de pagamento", "Metodo de pagamento"))?.let { stripMoneyGlyph(it) }
        val rideType = textNear(clean, listOf("Tipo de corrida"))

        val detailsIdx = clean.indexOfFirst { normalize(it).contains("detalhes da corrida") }
        val passenger = if (detailsIdx >= 0) clean.drop(detailsIdx + 1)
            .firstOrNull { !isDateTime(it) && !looksLikeAddress(it) && it.length in 1..30 && !it.contains("detalhes", true) } else null

        val addressCandidates = clean.filter { looksLikeAddress(it) }.distinct()
        val pickup = addressCandidates.getOrNull(0)
        val dropoff = addressCandidates.getOrNull(1)

        return ParsedRide(
            dateTime, date, duration, distance, earned, paid, cash, from99, completed99,
            otherCharges, paymentMethod, rideType, pickup, dropoff, passenger
        )
    }

    fun toEntity(parsed: ParsedRide, sourcePackage: String?, rawItems: List<String>): RideEntity {
        val key = "${parsed.dateTime}|${parsed.duration}|${"%.3f".format(Locale.US, parsed.distanceKm)}|${"%.2f".format(Locale.US, parsed.earned)}"
        val id = sha256(key)
        val difference = parsed.paidForRide?.let { parsed.earned - it }
        return RideEntity(
            id = id,
            date = parsed.date,
            dateTime = parsed.dateTime,
            duration = parsed.duration,
            distanceKm = parsed.distanceKm,
            earned = parsed.earned,
            paidForRide = parsed.paidForRide,
            difference = difference,
            cashReceived = parsed.cashReceived,
            amountFrom99 = parsed.amountFrom99,
            completedBy99 = parsed.completedBy99,
            otherCharges = parsed.otherCharges,
            paymentMethod = parsed.paymentMethod,
            rideType = parsed.rideType,
            pickup = parsed.pickup,
            dropoff = parsed.dropoff,
            passenger = parsed.passenger,
            sourcePackage = sourcePackage,
            rawText = rawItems.joinToString("\n")
        )
    }

    private fun labelIndex(items: List<String>, labels: List<String>): Int =
        items.indexOfFirst { item -> labels.any { normalize(item).contains(normalize(it)) } }

    private fun moneyNear(items: List<String>, labels: List<String>): Double? {
        val idx = labelIndex(items, labels)
        if (idx < 0) return null
        // Primeiro tenta o próprio nó (ex.: "Você ganhou R$7,20").
        parseMoney(items[idx])?.let { return it }
        // Depois procura nos nós próximos.
        for (i in (idx + 1)..minOf(idx + 6, items.lastIndex)) {
            parseMoney(items[i])?.let { return it }
        }
        return null
    }

    private fun durationNear(items: List<String>, labels: List<String>): String? {
        val idx = labelIndex(items, labels)
        if (idx < 0) return null
        for (i in idx..minOf(idx + 5, items.lastIndex)) {
            Regex("\\b(?:\\d+\\s*h\\s*)?(?:\\d+\\s*m\\s*)?(?:\\d+\\s*s)?\\b", RegexOption.IGNORE_CASE)
                .findAll(items[i])
                .map { it.value.replace(" ", "") }
                .firstOrNull { it.isNotBlank() && it.any(Char::isDigit) && (it.contains('m') || it.contains('s') || it.contains('h')) }
                ?.let { return it }
        }
        return null
    }

    private fun distanceNear(items: List<String>, labels: List<String>): Double? {
        val idx = labelIndex(items, labels)
        if (idx < 0) return null
        for (i in idx..minOf(idx + 5, items.lastIndex)) parseKm(items[i])?.let { return it }
        return null
    }

    private fun textNear(items: List<String>, labels: List<String>): String? {
        val idx = labelIndex(items, labels)
        if (idx < 0) return null
        val item = items[idx]
        val label = labels.firstOrNull { normalize(item).contains(normalize(it)) }
        if (label != null) {
            val nItem = normalize(item)
            val nLabel = normalize(label)
            val p = nItem.indexOf(nLabel)
            if (p >= 0) {
                // Usa o tamanho do rótulo original quando possível; se não, cai para o próximo nó.
                val colon = item.indexOf(':')
                if (colon >= 0 && colon < item.lastIndex) return item.substring(colon + 1).trim()
            }
        }
        return items.getOrNull(idx + 1)?.takeIf { parseMoney(it) == null }
    }

    fun parseMoney(text: String): Double? {
        val match = Regex("-?\\s*R\\$\\s*[0-9.]+,[0-9]{2}", RegexOption.IGNORE_CASE).find(text) ?: return null
        val negative = match.value.contains('-')
        val numeric = match.value.replace("R$", "", true).replace(".", "").replace(",", ".")
            .replace("-", "").trim().toDoubleOrNull() ?: return null
        return if (negative) -numeric else numeric
    }

    private fun parseKm(text: String): Double? {
        val m = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*km", RegexOption.IGNORE_CASE).find(text) ?: return null
        return m.groupValues[1].replace(',', '.').toDoubleOrNull()
    }

    private fun findDateTime(text: String): String? =
        Regex("\\b\\d{2}/\\d{2}/\\d{4}\\s+\\d{2}:\\d{2}(?::\\d{2})?\\b").find(text)?.value?.let {
            if (Regex("\\d{2}:\\d{2}:\\d{2}$").containsMatchIn(it)) it else "$it:00"
        }

    private fun isDateTime(text: String) = Regex("\\d{2}/\\d{2}/\\d{4}\\s+\\d{2}:\\d{2}(?::\\d{2})?").containsMatchIn(text)

    private fun looksLikeAddress(text: String): Boolean {
        val n = normalize(text)
        return (n.startsWith("av.") || n.startsWith("avenida") || n.startsWith("rua") || n.startsWith("r. ") ||
                n.startsWith("estrada") || n.startsWith("rodovia") || n.startsWith("travessa")) && text.length > 8
    }

    private fun stripMoneyGlyph(text: String) = text.replace("💵", "").trim()

    private fun normalize(s: String): String = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "").replace(Regex("\\s+"), " ").trim()

    private fun sha256(input: String): String = MessageDigest.getInstance("SHA-256")
        .digest(input.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

package com.anderson.corrida99reader

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rides")
data class RideEntity(
    @PrimaryKey val id: String,
    val date: String,
    val dateTime: String,
    val duration: String,
    val distanceKm: Double,
    val earned: Double,
    val paidForRide: Double?,
    val difference: Double?,
    val cashReceived: Double?,
    val amountFrom99: Double?,
    val completedBy99: Double?,
    val otherCharges: Double?,
    val paymentMethod: String?,
    val rideType: String?,
    val pickup: String?,
    val dropoff: String?,
    val passenger: String?,
    val sourcePackage: String?,
    val rawText: String,
    val createdAt: Long = System.currentTimeMillis()
)
